package PhonePe;

public enum VehicleType {
    SEDAN, HATCHBACK, SUV;
}
